//////////////////////////////////////////////////////////////////////////////////	 
//本程序只供学习使用，未经作者许可，不得用于其他用途
//技术资料唯一网站：http://www.weilaishijiejiqiren.icoc.me/
//单片机交流群：439190573
//淘宝店：https://shop130205202.taobao.com
//修改日期：2018/11/1
//版本：V3.0
//版权所有，盗版必究。
//未来世界机器人系列
//////////////////////////////////////////////////////////////////////////////////
#include "line.h"
#include "uart.h"
#include "motor.h"


unsigned char D1_Pin = 8;
unsigned char D2_Pin = 9;
unsigned char D3_Pin = 10;
unsigned char D4_Pin = 11;
unsigned char D5_Pin = 12;
unsigned char D6_Pin = 13;
unsigned char D7_Pin = 14;

unsigned char D1,D2,D3,D4,D5,D6,D7;

/*********************************************************************
 *  函数名称：line_Init
 *  函数功能：灰度传感器初始化
 *  形    参：无
 *  输    出：无
 *  备    注：无
 ********************************************************************/
 void line_Init()
 {
   pinMode(D1_Pin,INPUT);
   pinMode(D2_Pin,INPUT);
   pinMode(D3_Pin,INPUT);
   pinMode(D4_Pin,INPUT);
   pinMode(D5_Pin,INPUT);
   pinMode(D6_Pin,INPUT);
   pinMode(D7_Pin,INPUT);
 }
 /*********************************************************************
 *  函数名称：line_Read
 *  函数功能：灰度传感器数据读取
 *  形    参：无
 *  输    出：无
 *  备    注：无
 ********************************************************************/
 void line_Read()
 {
   D1 = digitalRead(D1_Pin);
   D2 = digitalRead(D2_Pin);
   D3 = digitalRead(D3_Pin);
   D4 = digitalRead(D4_Pin);
   D5 = digitalRead(D5_Pin);
   D6 = digitalRead(D6_Pin);
   D7 = digitalRead(D7_Pin);
 }
 /*********************************************************************
 *  函数名称：track_zhixian1()
 *  函数功能：直线循迹
 *  形    参：无
 *  输    出：无
 *  备    注：无
 ********************************************************************/
 void track_zhixian1()
{
  line_Read();
  if(D4 == 0)  
  {
    motor(50,50);
  }
  else if((D3 == 0)&&(D4 == 0))   
  {
    motor(35,50);
  }
  else if((D4 == 0)&&(D5 == 0))  
  {
    motor(50,35);
  }
  else if((D3 == 0)&&(D4 != 0))
  {
    motor(30,50);
  }
  else if((D4 != 0)&&(D5 == 0))   
  {
    motor(50,30);
  }
  else if((D2 == 0)&&(D3 == 0))     
  {
    motor(10,50);
  }
  else if((D5 == 0)&&(D6 == 0))    
  {
    motor(50,10);
  }
  else if((D2 == 0)&&(D3 != 0))   
  {
    motor(10,50);
  }
  else if((D5 != 0)&&(D6 == 0))  
  {
    motor(50,10);
  }
  else if((D1 == 0)&&(D2 == 0)) 
  {
    motor(10,50);
  }
  else if((D6 == 0)&&(D7 == 0))  
  {
    motor(50,10);
  }
  else if((D1 == 0)&&(D2 != 0))    
  {
    motor(10,50);
  }
  else if((D6 != 0)&&(D7 == 0))  
  {
    motor(50,10);
  }
  else   
  {
    motor(20,20);
  }
}
/*********************************************************************
 *  函数名称：track_zhixian2()
 *  函数功能：直线循迹
 *  形    参：无
 *  输    出：无
 *  备    注：无
 ********************************************************************/
void track_zhixian2()
{
	unsigned int Temp[2] = { 0 };       //数据缓存区	  
	
	Read_Data(Temp);
	switch(Temp[0])
	{                                                           //765 4321
		case 0x7E:		motor(0,40);	break;      //111 1110
		case 0x7C:		motor(10,40);	break;      //111 1100
		case 0x7D:		motor(15,40);	break;      //111 1101
		case 0x79:		motor(20,40);	break;      //111 1001
		case 0x7B:		motor(25,40);	break;      //111 1011
		case 0x73:		motor(38,40);	break;      //111 0011
		case 0x77:		motor(40,40);	break;      //111 0111		//正中间位置
		case 0x67:		motor(40,38);	break;      //110 0111
		case 0x6F:		motor(40,25);	break;      //110 1111			
		case 0x4F:		motor(40,20);	break;      //100 1111
		case 0x5F:		motor(40,15);	break;      //101 1111
		case 0x1F:		motor(40,10);	break;      //001 1111
		case 0x3F:		motor(40,0);	break;      //011 1111
		
		default :			motor(20,20);	break;
	}
      delay(5);
}
/*************************************
*函数名称：track_PID
*函数功能：直线循迹，用串口线连接，只输出偏移值
*参数：pwm：最大速度值，P：比例系数
*说明：
*			
**************************************/
void track_PID(int pwm,float P)
{
	static float Integral_error,Last_error;
	unsigned int temp_data[2] = { 0 };       //数据缓存区
	int error = 0;         //偏差值
	int L_Pwm,R_Pwm;			 //左右轮速度
	float I = 0,D = 0;		 //积分系数，微分系数
	
	Read_Data(temp_data);
	if(temp_data[0]==0)
	{
		error = -temp_data[1];
	}
	else
	{
		error = temp_data[1];
	}
	Integral_error += error;
	
	R_Pwm = (pwm-(error*P+Integral_error*I+(error-Last_error)*D));
	L_Pwm = (pwm+(error*P+Integral_error*I+(error-Last_error)*D));
	
	Last_error = error;
	
	if(pwm > 0)
	{
		if(L_Pwm > (pwm+10))
			L_Pwm = (pwm+10);
		if(R_Pwm > (pwm+10))
			R_Pwm = (pwm+10);
		if(L_Pwm <= 15)
			L_Pwm = 15;
		if(R_Pwm <= 15)
			R_Pwm = 15;
	}
	
	motor(L_Pwm,R_Pwm);
}
