//////////////////////////////////////////////////////////////////////////////////	 
//本程序只供学习使用，未经作者许可，不得用于其他用途
//技术资料唯一网站：http://www.weilaishijiejiqiren.icoc.me/
//单片机交流群：439190573
//淘宝店：https://shop130205202.taobao.com
//修改日期：2018/11/1
//版本：V3.0
//版权所有，盗版必究。
//未来世界机器人系列
//////////////////////////////////////////////////////////////////////////////////
#include "motor.h"

unsigned char  PWMA = 2;
unsigned char  PWMB = 3;
unsigned char  AIN1 = 4;
unsigned char  AIN2 = 5;
unsigned char  BIN1 = 6;
unsigned char  BIN2 = 7;


/*********************************************************************
 *  函数名称：motor_Init
 *  函数功能：电机初始化
 *  形    参：无
 *  输    出：无
 *  备    注：无
 ********************************************************************/
 void motor_Init()
 {
   pinMode(PWMA,OUTPUT);
   pinMode(PWMB,OUTPUT);
   pinMode(AIN1,OUTPUT);
   pinMode(AIN2,OUTPUT);
   pinMode(BIN1,OUTPUT);
   pinMode(BIN2,OUTPUT);
 }
 
/*********************************************************************
 *  函数名称：Read_Data
 *  函数功能：读取数据
 *  形    参：left: 左轮速度，right: 右轮速度.(取值范围：-100至100，负值为向后转，正值为向前转)
 *  输    出：无
 *  备    注：无
 ********************************************************************/
 void motor(char left , char right)
 {
////////////////////////左轮方向控制////////////////////////////
   if(left > 0)
   {
     digitalWrite(AIN1, HIGH);
     digitalWrite(AIN2, LOW);
   }
   else if(left < 0)
   {
     digitalWrite(AIN1, LOW);
     digitalWrite(AIN2, HIGH);
     left = -left;
   }
   else
   {
     digitalWrite(AIN1, LOW);
     digitalWrite(AIN2, LOW);
   }
////////////////////////右轮方向控制////////////////////////////
   if(right > 0)
   {
     digitalWrite(BIN1, HIGH);
     digitalWrite(BIN2, LOW);
   }
   else if(right < 0)
   {
     digitalWrite(BIN1, LOW);
     digitalWrite(BIN2, HIGH);
     right = -right;
   }
   else
   {
     digitalWrite(BIN1, LOW);
     digitalWrite(BIN2, LOW);
   } 
 ////////////////////////速度控制////////////////////////////
   analogWrite(PWMA, (left*2.55));
   analogWrite(PWMB, (right*2.55));
 }
 
 
