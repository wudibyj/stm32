#ifndef __UART_H
#define __UART_H

#include "STC15F2K60S2.H"



void Uart2_Init(unsigned int baud);
void Read_Data(unsigned int *Data);       





#endif

