//////////////////////////////////////////////////////////////////////////////////	 
//本程序只供学习使用，未经作者许可，不得用于其他用途
//技术资料唯一网站：http://www.weilaishijiejiqiren.icoc.me/
//单片机交流群：439190573
//淘宝店：https://shop130205202.taobao.com
//修改日期：2018/11/1
//版本：V3.0
//版权所有，盗版必究。
//未来世界机器人系列
//////////////////////////////////////////////////////////////////////////////////
#include "line.h"
#include "uart.h"
#include "motor.h"


unsigned char D1_Pin = 2;
unsigned char D2_Pin = 3;
unsigned char D3_Pin = 4;
unsigned char D4_Pin = 5;
unsigned char D5_Pin = 6;
unsigned char D6_Pin = 7;
unsigned char D7_Pin = 8;
unsigned char D8_Pin = 9;
unsigned char D9_Pin = 10;
unsigned char D10_Pin = 11;
unsigned char D11_Pin = 12;
unsigned char D12_Pin = 13;

unsigned char D1,D2,D3,D4,D5,D6,D7,D8,D9,D10,D11,D12;

/*********************************************************************
 *  函数名称：line_Init
 *  函数功能：灰度传感器初始化
 *  形    参：无
 *  输    出：无
 *  备    注：无
 ********************************************************************/
 void line_Init()
 {
   pinMode(D1_Pin,INPUT);
   pinMode(D2_Pin,INPUT);
   pinMode(D3_Pin,INPUT);
   pinMode(D4_Pin,INPUT);
   pinMode(D5_Pin,INPUT);
   pinMode(D6_Pin,INPUT);
   pinMode(D7_Pin,INPUT);
   pinMode(D8_Pin,INPUT);
   pinMode(D9_Pin,INPUT);
   pinMode(D10_Pin,INPUT);
   pinMode(D11_Pin,INPUT);
   pinMode(D12_Pin,INPUT);
 }
 /*********************************************************************
 *  函数名称：line_Read
 *  函数功能：灰度传感器数据读取
 *  形    参：无
 *  输    出：无
 *  备    注：无
 ********************************************************************/
 void line_Read()
 {
   D1 = digitalRead(D1_Pin);
   D2 = digitalRead(D2_Pin);
   D3 = digitalRead(D3_Pin);
   D4 = digitalRead(D4_Pin);
   D5 = digitalRead(D5_Pin);
   D6 = digitalRead(D6_Pin);
   D7 = digitalRead(D7_Pin);
   D8 = digitalRead(D8_Pin);
   D9 = digitalRead(D9_Pin);
   D10 = digitalRead(D10_Pin);
   D11 = digitalRead(D11_Pin);
   D12 = digitalRead(D12_Pin);
 }
 /*********************************************************************
 *  函数名称：track_zhixian1()
 *  函数功能：直线循迹
 *  形    参：无
 *  输    出：无
 *  备    注：无
 ********************************************************************/
 void track_zhixian1()
{
  line_Read();
  if((D6 == 0)&&(D7 == 0))    //6和7通道在线上
  {
    motor(40,40);
  }
  else if((D6 == 0)&&(D7 != 0))    //6通道在线上
  {
    motor(38,40);
  }
  else if((D7 == 0)&&(D6 != 0))    //7通道在线上
  {
    motor(40,38);
  }
  else if((D5 == 0)&&(D6 == 0))    //5和6通道在线上
  {
    motor(35,40);		
  }
  else if((D7 == 0)&&(D8 == 0))    //7和8通道在线上
  {
    motor(40,35);
  }
  else if((D5 ==0)&&(D6 != 0))    //5通道在线上
  {
    motor(30,40);
  }
  else if((D8 ==0)&&(D7 != 0))    //8通道在线上
  {				 
    motor(40,30);
  }
  else if((D4 == 0)&&(D5 == 0))    //4和5通道在线上
  {
    motor(25,40);	
  }
  else if((D8 == 0)&&(D9 == 0))    //8和9通道在线上
  {
    motor(40,25);
  }	
  else if((D4 ==0)&&(D5 != 0))    //4通道在线上
  {
    motor(20,40);
  }
  else if((D9 ==0)&&(D8 != 0))    //9通道在线上
  {				 
    motor(40,20);
  }
  else if((D3 == 0)&&(D4 == 0))    //3和4通道在线上
  {
    motor(15,40);	
  }
  else if((D9 == 0)&&(D10 == 0))    //9和10通道在线上
  {
    motor(40,15);
  }	
  else if((D3 ==0)&&(D4 != 0))    //3通道在线上
  {
    motor(10,40);
  }
  else if((D10 ==0)&&(D9 != 0))    //10通道在线上
  {				 
    motor(40,10);
  }
  else if((D2 == 0)&&(D3 == 0))    //2和3通道在线上
  {
    motor(10,40);	
  }
  else if((D10 == 0)&&(D11 == 0))    //10和11通道在线上
  {
    motor(40,10);
  }	
  else if((D2 == 0)&&(D3 != 0))    //2通道在线上
  {
    motor(10,40);
  }
  else if((D11 ==0)&&(D10 != 0))    //11通道在线上
  {
    motor(40,10);
  }
  else if((D1 == 0)&&(D2 == 0))    //1和2通道在线上
  {
    motor(0,40);	
  }
  else if((D10 == 0)&&(D11 == 0))    //11和12通道在线上
  {
    motor(40,0);
  }	
  else if(D1 == 0)    //1通道在线上
  {
    motor(0,40);
  }
  else if(D12 == 0)    //12通道在线上
  {
    motor(40,0);
  }
  else   
  {
    motor(20,20);
  }

}
/*********************************************************************
 *  函数名称：track_zhixian2()
 *  函数功能：直线循迹
 *  形    参：无
 *  输    出：无
 *  备    注：无
 ********************************************************************/
void track_zhixian2()
{
	unsigned int Temp[2] = { 0 };       //数据缓存区	  
	
	Read_Data(Temp);
	switch(Temp[0])						    //111
	{                                        		    //2109 87654321
		case 0x0FFE:		motor(0,40);	break;      //1111 11111110
		case 0x0FFC:		motor(0,40);	break;      //1111 11111100
		case 0x0FFD:		motor(10,40);	break;      //1111 11111101
		case 0x0FF9:		motor(10,40);	break;      //1111 11111001
		case 0x0FFB:		motor(10,40);	break;      //1111 11111011
		case 0x0FF3:		motor(15,40);	break;      //1111 11110011
		case 0x0FF7:		motor(20,40);	break;      //1111 11110111
		case 0x0FE7:		motor(25,40);	break;      //1111 11100111
		case 0x0FEF:		motor(30,40);	break;      //1111 11101111
		case 0x0FCF:		motor(35,40);	break;      //1111 11001111
		case 0x0FDF:		motor(38,40);	break;      //1111 11011111
		case 0x0F9F:		motor(40,40);	break;      //1111 10011111		//正中间位置
		case 0x0FBF:		motor(40,38);	break;      //1111 10111111
		case 0x0F3F:		motor(40,35);	break;      //1111 00111111
		case 0x0F7F:		motor(40,30);	break;      //1111 01111111
		case 0x0E7F:		motor(40,25);	break;      //1110 01111111
		case 0x0EFF:		motor(40,20);	break;      //1110 11111111
		case 0x0CFF:		motor(40,15);	break;      //1100 11111111
		case 0x0DFF:		motor(40,10);	break;      //1101 11111111
		case 0x09FF:		motor(40,10);	break;      //1001 11111111
		case 0x0BFF:		motor(40,10);	break;      //1011 11111111
		case 0x03FF:		motor(40,0);	break;      //0011 11111111
		case 0x07FF:		motor(40,0);	break;      //0111 11111111
		
		default :			motor(20,20);	break;
	}
      delay(5);
}
/*************************************
*函数名称：track_PID
*函数功能：直线循迹，用串口线连接，只输出偏移值
*参数：pwm：最大速度值，P：比例系数
*说明：
*			
**************************************/
void track_PID(int pwm,float P)
{
	static float Integral_error,Last_error;
	unsigned int temp_data[2] = { 0 };       //数据缓存区
	int error = 0;         //偏差值
	int L_Pwm,R_Pwm;			 //左右轮速度
	float I = 0,D = 0;		 //积分系数，微分系数
	
	Read_Data(temp_data);
	if(temp_data[0]==0)
	{
		error = -temp_data[1];
	}
	else
	{
		error = temp_data[1];
	}
	Integral_error += error;
	
	R_Pwm = (pwm-(error*P+Integral_error*I+(error-Last_error)*D));
	L_Pwm = (pwm+(error*P+Integral_error*I+(error-Last_error)*D));
	
	Last_error = error;
	
	if(pwm > 0)
	{
		if(L_Pwm > (pwm+10))
			L_Pwm = (pwm+10);
		if(R_Pwm > (pwm+10))
			R_Pwm = (pwm+10);
		if(L_Pwm <= 15)
			L_Pwm = 15;
		if(R_Pwm <= 15)
			R_Pwm = 15;
	}
	
	motor(L_Pwm,R_Pwm);
}




