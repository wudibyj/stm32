/*--------------------------------------------------------------*/
//��ֹ�ظ�����
#ifndef	__LINE_H__
#define __LINE_H__
/*--------------------------------------------------------------*/

void track_zhixian1(void);
void track_zhixian2(void);
void track_PID(int pwm,float P);


#endif

