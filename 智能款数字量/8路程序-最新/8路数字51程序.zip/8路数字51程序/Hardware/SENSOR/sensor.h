#ifndef __SENSOR_H
#define	__SENSOR_H

#include <STC15F2K60S2.h>

/*-------------���ֶ˿�----------------*/
#define D1 digtal(1)
#define D2 digtal(2)
#define D3 digtal(3)
#define D4 digtal(4)
#define D5 digtal(5)
#define D6 digtal(6)
#define D7 digtal(7)
#define D8 digtal(8)


unsigned char digtal(unsigned char channel);  	//��ȡXͨ������ֵ��0��1�� 1~8						  


#endif 
