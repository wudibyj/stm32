#ifndef __LINE_H
#define __LINE_H

#include <Arduino.h>

void line_Init();
void line_Read();
void track_zhixian1();
void track_zhixian2();
void track_PID(int pwm,float P);

#endif


