#ifndef __MOTOR_H
#define __MOTOR_H

#include <Arduino.h>

void motor_Init();
void motor(char left , char right);

#endif


