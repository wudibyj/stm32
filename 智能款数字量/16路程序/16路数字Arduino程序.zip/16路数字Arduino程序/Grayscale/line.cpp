﻿//////////////////////////////////////////////////////////////////////////////////	 
//本程序只供学习使用，未经作者许可，不得用于其他用途
//技术资料唯一网站：http://www.weilaishijiejiqiren.icoc.me/
//单片机交流群：439190573
//淘宝店：https://shop130205202.taobao.com
//修改日期：2018/11/1
//版本：V3.0
//版权所有，盗版必究。
//未来世界机器人系列
//////////////////////////////////////////////////////////////////////////////////
#include "line.h"
#include "uart.h"
#include "motor.h"


unsigned char D1_Pin = 2;
unsigned char D2_Pin = 3;
unsigned char D3_Pin = 4;
unsigned char D4_Pin = 5;
unsigned char D5_Pin = 6;
unsigned char D6_Pin = 7;
unsigned char D7_Pin = 8;
unsigned char D8_Pin = 9;
unsigned char D9_Pin = 10;
unsigned char D10_Pin = 11;
unsigned char D11_Pin = 12;
unsigned char D12_Pin = 13;
unsigned char D13_Pin = 20;
unsigned char D14_Pin = 21;
unsigned char D15_Pin = 22;
unsigned char D16_Pin = 23;

unsigned char D1,D2,D3,D4,D5,D6,D7,D8,D9,D10,D11,D12,D13,D14,D15,D16;

/*********************************************************************
 *  函数名称：line_Init
 *  函数功能：灰度传感器初始化
 *  形    参：无
 *  输    出：无
 *  备    注：无
 ********************************************************************/
 void line_Init()
 {
   pinMode(D1_Pin,INPUT);
   pinMode(D2_Pin,INPUT);
   pinMode(D3_Pin,INPUT);
   pinMode(D4_Pin,INPUT);
   pinMode(D5_Pin,INPUT);
   pinMode(D6_Pin,INPUT);
   pinMode(D7_Pin,INPUT);
   pinMode(D8_Pin,INPUT);
   pinMode(D9_Pin,INPUT);
   pinMode(D10_Pin,INPUT);
   pinMode(D11_Pin,INPUT);
   pinMode(D12_Pin,INPUT);
   pinMode(D13_Pin,INPUT);
   pinMode(D14_Pin,INPUT); 
   pinMode(D15_Pin,INPUT);
   pinMode(D16_Pin,INPUT); 
 }
 /*********************************************************************
 *  函数名称：line_Read
 *  函数功能：灰度传感器数据读取
 *  形    参：无
 *  输    出：无
 *  备    注：无
 ********************************************************************/
 void line_Read()
 {
   D1 = digitalRead(D1_Pin);
   D2 = digitalRead(D2_Pin);
   D3 = digitalRead(D3_Pin);
   D4 = digitalRead(D4_Pin);
   D5 = digitalRead(D5_Pin);
   D6 = digitalRead(D6_Pin);
   D7 = digitalRead(D7_Pin);
   D8 = digitalRead(D8_Pin);
   D9 = digitalRead(D9_Pin);
   D10 = digitalRead(D10_Pin);
   D11 = digitalRead(D11_Pin);
   D12 = digitalRead(D12_Pin);
   D13 = digitalRead(D13_Pin);
   D14 = digitalRead(D14_Pin);   
   D15 = digitalRead(D15_Pin);
   D16 = digitalRead(D16_Pin); 
 }
 /*********************************************************************
 *  函数名称：track_zhixian1()
 *  函数功能：直线循迹
 *  形    参：无
 *  输    出：无
 *  备    注：无
 ********************************************************************/
 void track_zhixian1()
{
  line_Read();
	if((D8 == 0)&&(D9 == 0))    //8和9通道在线上
	{
		motor(40,40);
	}
	else if((D8 == 0)&&(D9 != 0))    //8通道在线上
	{
		motor(38,40);
	}
	else if((D9 == 0)&&(D8 != 0))    //9通道在线上
	{
		motor(40,38);
	}
	else if((D7 == 0)&&(D8 == 0))    //7和8通道在线上
	{
		motor(38,40);		
	}
	else if((D9 == 0)&&(D10 == 0))    //9和10通道在线上
	{
		motor(40,38);
	}
	else if((D7 ==0)&&(D8 != 0))    //7通道在线上
	{
		motor(35,40);
	}
	else if((D10 ==0)&&(D9 != 0))    //10通道在线上
	{				 
		motor(40,35);
	}
	else if((D6 == 0)&&(D7 == 0))    //6和7通道在线上
	{
		motor(35,40);	
	}
	else if((D10 == 0)&&(D11 == 0))    //10和11通道在线上
	{
		motor(40,35);
	}	
	else if((D6 ==0)&&(D7 != 0))    //6通道在线上
	{
		motor(30,40);
	}
	else if((D11 ==0)&&(D10 != 0))    //11通道在线上
	{				 
		motor(40,30);
	}
	else if((D5 == 0)&&(D6 == 0))    //5和6通道在线上
	{
		motor(25,40);	
	}
	else if((D11 == 0)&&(D12 == 0))    //11和12通道在线上
	{
		motor(40,25);
	}	
	else if((D5 ==0)&&(D6 != 0))    //5通道在线上
	{
		motor(20,40);
	}
	else if((D12 ==0)&&(D11 != 0))    //12通道在线上
	{				 
		motor(40,20);
	}
	else if((D4 == 0)&&(D5 == 0))    //4和5通道在线上
	{
		motor(20,40);	
	}
	else if((D12 == 0)&&(D13 == 0))    //12和13通道在线上
	{
		motor(40,20);
	}	
	else if((D4 == 0)&&(D5 != 0))    //4通道在线上
	{
		motor(15,40);
	}
	else if((D13 ==0)&&(D12 != 0))    //13通道在线上
	{
		motor(40,15);
	}
	else if((D3 == 0)&&(D4 == 0))    //3和4通道在线上
	{
		motor(15,40);	
	}
	else if((D13 == 0)&&(D14 == 0))    //13和14通道在线上
	{
		motor(40,15);
	}	
	else if((D3 == 0)&&(D4 != 0))    //3通道在线上
	{
		motor(10,40);
	}
	else if((D14 ==0)&&(D13 != 0))    //14通道在线上
	{
		motor(40,10);
	}
	else if((D2 == 0)&&(D3 == 0))    //2和3通道在线上
	{
		motor(10,40);	
	}
	else if((D14 == 0)&&(D15 == 0))    //14和15通道在线上
	{
		motor(40,10);
	}	
	else if((D2 == 0)&&(D3 != 0))    //2通道在线上
	{
		motor(10,40);
	}
	else if((D15 ==0)&&(D14 != 0))    //15通道在线上
	{
		motor(40,10);
	}
	else if((D1 == 0)&&(D2 == 0))    //1和2通道在线上
	{
		motor(0,40);	
	}
	else if((D15 == 0)&&(D16 == 0))    //15和16通道在线上
	{
		motor(40,0);
	}	
	else if((D1 == 0)&&(D2 != 0))    //1通道在线上
	{
		motor(0,40);
	}
	else if((D16 ==0)&&(D15 != 0))    //16通道在线上
	{
		motor(40,0);
	}	
	
	else   
	{
		motor(20,20);
	}

}
/*********************************************************************
 *  函数名称：track_zhixian2()
 *  函数功能：直线循迹
 *  形    参：无
 *  输    出：无
 *  备    注：无
 ********************************************************************/
void track_zhixian2()
{
	unsigned int Temp[2] = { 0 };       //数据缓存区	  
	
	Read_Data(Temp);
	switch(Temp[0])						    //1111111
	{                                        		    //65432109 87654321
		case 0xFFFE:		motor(0,40);	break;      //11111111 11111110
		case 0xFFFC:		motor(0,40);	break;      //11111111 11111100
		case 0xFFFD:		motor(10,40);	break;      //11111111 11111101
		case 0xFFF9:		motor(10,40);	break;      //11111111 11111001
		case 0xFFFB:		motor(10,40);	break;      //11111111 11111011
		case 0xFFF3:		motor(15,40);	break;      //11111111 11110011
		case 0xFFF7:		motor(15,40);	break;      //11111111 11110111
		case 0xFFE7:		motor(20,40);	break;      //11111111 11100111
		case 0xFFEF:		motor(20,40);	break;      //11111111 11101111
		case 0xFFCF:		motor(25,40);	break;      //11111111 11001111
		case 0xFFDF:		motor(30,40);	break;      //11111111 11011111
		case 0xFF9F:		motor(35,40);	break;      //11111111 10011111
		case 0xFFBF:		motor(35,40);	break;      //11111111 10111111
		case 0xFF3F:		motor(38,40);	break;      //11111111 00111111
		case 0xFF7F:		motor(38,40);	break;      //11111111 01111111
		case 0xFE7F:		motor(40,40);	break;      //11111110 01111111		//正中间位置
		case 0xFEFF:		motor(40,38);	break;      //11111110 11111111
		case 0xFCFF:		motor(40,38);	break;      //11111100 11111111
		case 0xFDFF:		motor(40,35);	break;      //11111101 11111111
		case 0xF9FF:		motor(40,35);	break;      //11111001 11111111
		case 0xFBFF:		motor(40,30);	break;      //11111011 11111111
		case 0xF3FF:		motor(40,25);	break;      //11110011 11111111
		case 0xF7FF:		motor(40,20);	break;      //11110111 11111111
 		case 0xE7FF:		motor(40,20);	break;      //11100111 11111111
		case 0xEFFF:		motor(40,15);	break;      //11101111 11111111
		case 0xCFFF:		motor(40,15);	break;      //11001111 11111111
		case 0xDFFF:		motor(40,10);	break;      //11011111 11111111
		case 0x9FFF:		motor(40,10);	break;      //10011111 11111111
		case 0xBFFF:		motor(40,10);	break;      //10111111 11111111
		case 0x3FFF:		motor(40,0);	break;      //00111111 11111111
		case 0x7FFF:		motor(40,0);	break;      //01111111 11111111
		
		default :			motor(20,20);	break;
	}
    delay(5);
}
/*************************************
*函数名称：track_PID
*函数功能：直线循迹，用串口线连接，只输出偏移值
*参数：pwm：最大速度值，P：比例系数
*说明：
*			
**************************************/
void track_PID(int pwm,float P)
{
	static float Integral_error,Last_error;
	unsigned int temp_data[2] = { 0 };       //数据缓存区
	int error = 0;         //偏差值
	int L_Pwm,R_Pwm;			 //左右轮速度
	float I = 0,D = 0;		 //积分系数，微分系数
	
	Read_Data(temp_data);
	if(temp_data[0]==0)
	{
		error = -temp_data[1];
	}
	else
	{
		error = temp_data[1];
	}
	Integral_error += error;
	
	R_Pwm = (pwm-(error*P+Integral_error*I+(error-Last_error)*D));
	L_Pwm = (pwm+(error*P+Integral_error*I+(error-Last_error)*D));
	
	Last_error = error;
	
	if(pwm > 0)
	{
		if(L_Pwm > (pwm+10))
			L_Pwm = (pwm+10);
		if(R_Pwm > (pwm+10))
			R_Pwm = (pwm+10);
		if(L_Pwm <= 15)
			L_Pwm = 15;
		if(R_Pwm <= 15)
			R_Pwm = 15;
	}
	
	motor(L_Pwm,R_Pwm);
}




