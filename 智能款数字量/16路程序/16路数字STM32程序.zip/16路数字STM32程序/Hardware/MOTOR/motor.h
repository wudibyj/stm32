#ifndef __MOTOR_H
#define __MOTOR_H 		

#include "stm32f10x.h"


void Motor_Config(void);
void motor(int pwm1, int pwm2);

#endif







