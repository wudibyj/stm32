#ifndef	__MOTOR_H
#define	__MOTOR_H

#include	<STC15F2K60S2.H>


sbit BIN1 = P0^2;
sbit BIN2 = P0^3;
sbit AIN1 = P0^1;
sbit AIN2 = P0^0;

/**********************************************************/
void Motor_Init(void);
void motor(unsigned char PWMA, unsigned char PWMB);


#endif

